// lib/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'login_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.brown.shade700,
              Colors.white,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Stack(
          children: [
            // Background logo with 25% transparency, occupying 50% of the screen height
            Center(
              child: Opacity(
                opacity: 0.30,
                child: Image.asset(
                  'assets/images/logo.png', // Path to your logo
                  width: MediaQuery.of(context).size.width * 50,
                  height: MediaQuery.of(context).size.height * 50,
                  fit: BoxFit.contain,
                ),
              ),
            ),
            // Main content
            Center(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Display small logo at the top
                      Padding(
                        padding: const EdgeInsets.only(bottom: 20.0),
                        child: Image.asset(
                          'assets/images/logo.png', // Path to your logo
                          width: 200, // Set width as needed
                          height: 200, // Set height as needed
                        ),
                      ),
                      // Welcome message container
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.brown.shade100.withOpacity(0.8),
                          borderRadius: BorderRadius.circular(10.0),
                          border: Border.all(color: Colors.brown, width: 2.0),
                        ),
                        padding: const EdgeInsets.all(16.0),
                        margin: const EdgeInsets.only(bottom: 20.0),
                        child: Column(
                          children: [
                            // Welcome message
                            Text(
                              'Selamat Datang di RentCamp!',
                              style: TextStyle(
                                fontSize: 28.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.brown.shade900,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 10.0),
                            // Description message
                            Text(
                              'Cari perlengkapan camping? Yuk di RentCamp aja!!!',
                              style: TextStyle(
                                fontSize: 18.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.brown.shade700,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                      // Login button
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => LoginScreen()),
                          );
                        },
                        child: Text(
                          'Masuk',
                          style: TextStyle(
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor:
                              Colors.brown, // Button background color
                          foregroundColor: Colors.white, // Button text color
                          padding: EdgeInsets.symmetric(
                              vertical: 14.0,
                              horizontal: 40.0), // Padding for button
                          shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(20.0), // Rounded button
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

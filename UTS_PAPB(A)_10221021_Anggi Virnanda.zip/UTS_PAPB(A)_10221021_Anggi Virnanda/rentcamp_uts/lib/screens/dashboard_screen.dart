import 'package:flutter/material.dart';
import 'package_selection_screen.dart';
import 'store_location_screen.dart';
import 'pricing_screen.dart';
import 'payment_screen.dart';
import 'review_screen.dart';

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard'),
        backgroundColor: Colors.brown,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.brown.shade700,
              Colors.white
            ], // Gradien dari Coklat ke Putih
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Stack(
          children: [
            // Gambar latar belakang dengan transparansi
            Opacity(
              opacity: 0.25, // Transparansi 25%
              child: Image.asset(
                'assets/images/logo.png', // Ganti dengan path gambar latar belakang Anda
                fit: BoxFit.cover,
                width: double.infinity,
                height: double.infinity,
              ),
            ),
            // Konten utama
            SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    // Paket camping
                    GridView.count(
                      crossAxisCount: 2,
                      shrinkWrap:
                          true, // Mengizinkan GridView digunakan dalam SingleChildScrollView
                      physics:
                          NeverScrollableScrollPhysics(), // Menonaktifkan scrolling untuk GridView
                      children: [
                        buildPackageCard(context, 'Paket Camping 1', 'Lokasi 1',
                            100, 'assets/images/package1.png'),
                        buildPackageCard(context, 'Paket Camping 2', 'Lokasi 2',
                            120, 'assets/images/package2.png'),
                        buildPackageCard(context, 'Paket Camping 3', 'Lokasi 3',
                            90, 'assets/images/package3.png'),
                        buildPackageCard(context, 'Paket Camping 4', 'Lokasi 4',
                            110, 'assets/images/package4.png'),
                        buildPackageCard(context, 'Paket Camping 5', 'Lokasi 5',
                            130, 'assets/images/package5.png'),
                        buildPackageCard(context, 'Paket Camping 6', 'Lokasi 6',
                            140, 'assets/images/package6.png'),
                      ],
                    ),
                    SizedBox(height: 20.0), // Spasi sebelum ulasan
                    // Ulasan Pelanggan
                    Text(
                      'Ulasan Pelanggan',
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 10.0),
                    buildReviewCard('Pengguna 1',
                        'Pengalaman yang luar biasa! Semuanya sempurna.'),
                    buildReviewCard('Pengguna 2',
                        'Menghadapi waktu yang menyenangkan, sangat direkomendasikan!'),
                    buildReviewCard('Pengguna 3',
                        'Lokasi yang indah, akan mengunjungi lagi!'),
                    buildReviewCard('Pengguna 4',
                        'Terjangkau dan menyenangkan, bagus untuk keluarga.'),
                    buildReviewCard('Pengguna 5',
                        'Layanan yang luar biasa, staf yang sangat ramah.'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildPackageCard(BuildContext context, String title, String location,
      int price, String imagePath) {
    return Card(
      elevation: 4.0,
      child: Column(
        children: [
          Image.asset(
            imagePath,
            fit: BoxFit.cover,
            height: 100, // Sesuaikan tinggi sesuai kebutuhan
            width: double.infinity,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(title,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          Text('Lokasi: $location', style: TextStyle(fontSize: 14)),
          Text('Harga: \$${price.toString()}', style: TextStyle(fontSize: 14)),
          ElevatedButton(
            onPressed: () {
              // Arahkan ke layar pembayaran atau tampilkan opsi pembayaran
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => PaymentScreen()));
            },
            child: Text('Bayar Sekarang'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.brown, // Warna latar belakang tombol
              foregroundColor: Colors.white, // Warna teks tombol
            ),
          ),
        ],
      ),
    );
  }

  Widget buildReviewCard(String user, String review) {
    return Card(
      elevation: 2.0,
      margin: EdgeInsets.symmetric(vertical: 8.0),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(user,
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            SizedBox(height: 4.0),
            Text(review, style: TextStyle(fontSize: 14)),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

class ReviewScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Review')),
      body: ListView(
        children: [
          ListTile(
              title: Text('User 1'),
              subtitle: Text('Pengalaman menyewa sangat memuaskan!')),
          ListTile(
              title: Text('User 2'),
              subtitle: Text('Paket lengkap dan sesuai kebutuhan!')),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Tambahkan logika untuk menambahkan review baru
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

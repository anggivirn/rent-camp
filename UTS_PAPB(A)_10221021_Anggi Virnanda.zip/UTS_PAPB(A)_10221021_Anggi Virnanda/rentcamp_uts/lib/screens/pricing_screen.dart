import 'package:flutter/material.dart';

class PricingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Harga Paket Camping')),
      body: Center(
        child: Column(
          children: [
            Text('Paket A - Rp 200.000'),
            Text('Paket B - Rp 350.000'),
            Text('Paket C - Rp 500.000'),
          ],
        ),
      ),
    );
  }
}

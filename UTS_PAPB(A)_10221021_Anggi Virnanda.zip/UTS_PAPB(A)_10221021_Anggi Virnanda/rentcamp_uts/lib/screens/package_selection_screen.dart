import 'package:flutter/material.dart';

class PackageSelectionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Pilih Paket Camping')),
      body: ListView(
        children: [
          ListTile(
              title: Text('Paket A - Basic'),
              subtitle: Text('Harga: Rp 200.000')),
          ListTile(
              title: Text('Paket B - Standard'),
              subtitle: Text('Harga: Rp 350.000')),
          ListTile(
              title: Text('Paket C - Premium'),
              subtitle: Text('Harga: Rp 500.000')),
        ],
      ),
    );
  }
}

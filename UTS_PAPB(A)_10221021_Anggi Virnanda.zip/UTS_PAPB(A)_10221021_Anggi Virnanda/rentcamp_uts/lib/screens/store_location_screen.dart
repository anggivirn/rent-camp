import 'package:flutter/material.dart';

class StoreLocationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Lokasi Toko')),
      body: Center(child: Text('Lokasi Toko RentCamp')),
    );
  }
}

class ReviewModel {
  final String userId;
  final String userName;
  final String content;
  final DateTime date;

  ReviewModel({
    required this.userId,
    required this.userName,
    required this.content,
    required this.date,
  });

  // Convert JSON to ReviewModel
  factory ReviewModel.fromJson(Map<String, dynamic> json) {
    return ReviewModel(
      userId: json['userId'],
      userName: json['userName'],
      content: json['content'],
      date: DateTime.parse(json['date']),
    );
  }

  // Convert ReviewModel to JSON
  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'userName': userName,
      'content': content,
      'date': date.toIso8601String(),
    };
  }
}

class PackageModel {
  final String id;
  final String name;
  final String description;
  final double price;

  PackageModel({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
  });

  // Convert JSON to PackageModel
  factory PackageModel.fromJson(Map<String, dynamic> json) {
    return PackageModel(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      price: json['price'],
    );
  }

  // Convert PackageModel to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'price': price,
    };
  }
}

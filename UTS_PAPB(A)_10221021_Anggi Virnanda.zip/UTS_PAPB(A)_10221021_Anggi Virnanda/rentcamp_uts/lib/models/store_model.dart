class StoreModel {
  final String id;
  final String name;
  final String location;
  final String contact;

  StoreModel({
    required this.id,
    required this.name,
    required this.location,
    required this.contact,
  });

  // Convert JSON to StoreModel
  factory StoreModel.fromJson(Map<String, dynamic> json) {
    return StoreModel(
      id: json['id'],
      name: json['name'],
      location: json['location'],
      contact: json['contact'],
    );
  }

  // Convert StoreModel to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'location': location,
      'contact': contact,
    };
  }
}

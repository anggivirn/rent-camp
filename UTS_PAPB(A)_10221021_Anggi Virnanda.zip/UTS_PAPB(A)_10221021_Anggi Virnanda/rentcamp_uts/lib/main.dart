import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(RentCampApp());
}

class RentCampApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RentCamp',
      theme: ThemeData(
        primarySwatch: Colors.brown,
      ),
      home: HomeScreen(), // Panggil HomeScreen sebagai tampilan awal
      debugShowCheckedModeBanner: false, // Hilangkan banner debug
    );
  }
}

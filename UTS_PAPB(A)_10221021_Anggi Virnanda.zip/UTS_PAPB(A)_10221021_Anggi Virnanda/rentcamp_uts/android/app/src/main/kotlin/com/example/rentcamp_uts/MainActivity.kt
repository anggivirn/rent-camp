package com.example.rentcamp_uts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
